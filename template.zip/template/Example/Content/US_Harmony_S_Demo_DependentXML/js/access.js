
var stateList;
var accessList;


function initialize() {
	//create new iScroller
	myScroll = new iScroll('xmlContainer');

	// fetch the state/county XML list
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.open("GET","xml/USStateList.xml",false);
	xmlhttp.send();
	stateList = xmlhttp.responseXML;

	// fetch the access XML list
	xmlhttp = new XMLHttpRequest();
	xmlhttp.open("GET","xml/SampleAccess.xml",false);
	xmlhttp.send();
	accessList = xmlhttp.responseXML;

	// initialize the state and county dropDowns
	initDropDowns();
	}

function initDropDowns() {
	StateDropDown();
	changeState();
	}

function addOption(selectbox,text,value) {
	var optn = document.createElement("Option");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
	}

function StateDropDown() {
	// add everything to the state list
	var root = stateList.documentElement;
	var nodelist = root.getElementsByTagName('name');
	for (i = 0; i < nodelist.length; i++)
		addOption(document.form1.State, nodelist[i].textContent, nodelist[i].textContent);
	}

function CountyDropDown() {
	// clear the old list
	while(document.form2.County.length > 0)
		document.form2.County.remove(0);

	// find this state's XML node
	var stateName = document.form1.State.value;
	var root = stateList.documentElement;
	var nodelist = root.getElementsByTagName('state');
	for (i = 0; i < nodelist.length; i++) {
		var curName = nodelist[i].getElementsByTagName('name')[0].textContent;
		if (curName == stateName) {
			var counties = nodelist[i].getElementsByTagName('county');
			for (j = 0; j < counties.length; j++)
				addOption(document.form2.County, counties[j].textContent, counties[j].textContent);
			break;
			}
		}
	}

function changeState() {
	CountyDropDown();
	writeDataTable();
	}

function writeDataTable() {
	// grab data based on the county index
	// (data is recycled since this is just a sample)
	var countyNodes = accessList.documentElement.getElementsByTagName('county');

	//Display Commercial data  
	HTMLCodeHeadline = "";
	HTMLCodeTable = "";

	if (countyNodes.length > 0) //we must have at least one element
		{
		//write out headline information
		HTMLCodeHeadline += "<span>Formulary status of Proxitin</span><br>on selected plans in "
			+ "<strong>"
			+ document.form2.County.value
			+ ", "
			+ document.form1.State.value
			+ "</strong>";

		//write out data table header
		HTMLCodeTable += "<div class='type'>Commercial</div>";
		displayHeadline.innerHTML = HTMLCodeHeadline;

		//write out data table
		var plans = countyNodes[document.form2.County.selectedIndex % countyNodes.length].getElementsByTagName('plan');
		HTMLCodeTable += '<table cellspacing="0" cellpadding="0" class="data_table">';
		for (var j = 0; j < plans.length; j++) {
			var plan = plans[j];
			var drugs = plan.getElementsByTagName("drug");
			
			HTMLCodeTable += '<tr>'
				+ '<td class="provider_cell">' + plan.getAttribute("provider_name") + '</td>'
				+ '<td class="proxitin_cell data" nowrap>' + drugs[0].getAttribute("status") + '</td>'
				+ '<td class="data" nowrap>' + drugs[1].getAttribute("status") + '</td>'
				+ '<td class="data" nowrap>' + drugs[2].getAttribute("status") + '</td>'
				+ '</tr>';
			}
		HTMLCodeTable += '</table>';
		displayCommercial.innerHTML = HTMLCodeTable;
		}

	//refresh scroller to account for any change in size of data container
	myScroll.refresh();
	}
