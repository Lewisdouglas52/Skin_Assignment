// JavaScript Document

function addOption(selectbox,text,value )
{
	var optn = document.createElement("Option");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
}

function CountyDropDown()
{
	while(document.form2.County.length > 0)
		document.form2.County.remove(0);
	
	var xmlDoc = xmlData[document.form1.State.value];
  	var root = xmlDoc.documentElement;
	var nodelist = root.getElementsByTagName('county');

	var Commercialnodelist = xmlDoc.getElementsByTagName('county');
	
	for (i=0; i < Commercialnodelist.length; ++i)			
		addOption(document.form2.County, Commercialnodelist[i].attributes[1].textContent, Commercialnodelist[i].attributes[1].textContent);
}