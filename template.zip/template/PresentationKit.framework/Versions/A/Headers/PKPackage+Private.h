#import "PKPackage.h"

@interface PKPackage ()

@property (nonatomic, strong, readwrite) PKPresentation* presentation;
@property (nonatomic, strong, readwrite) NSString* pathToRoot;

@end