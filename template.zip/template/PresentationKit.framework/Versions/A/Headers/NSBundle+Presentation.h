
@interface NSBundle (Presentation)

+ (NSBundle*) presentationBundle;

@end
