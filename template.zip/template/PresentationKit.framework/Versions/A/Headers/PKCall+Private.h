#import "PKCall.h"

@interface PKCall(Private)
- (NSDate*) realStartTime;
@end
