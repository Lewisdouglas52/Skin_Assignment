@class PKBrand;
@class PKPresentation;
@class PKSupplementalMedia;

typedef enum {
    kPackageStatusInstalled,
    kPackageStatusUpdateIsAvailable,
    kPackageStatusUpdateIsRequired,
} PackageStatus;

extern NSString* const kPackageAssetTypePresentation;
extern NSString* const kPackageAssetTypeBriefcase;


@interface PKPackage : NSManagedObject

@property (nonatomic, retain) NSString * assetType;
@property (nonatomic, retain) NSString * idFromCMS;
@property (nonatomic, retain) NSString * country;
@property (nonatomic, retain) NSDate * creationDate;
@property (nonatomic, retain) NSString * language;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * summary;
@property (nonatomic, retain) NSString * thumbnailPath;
@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSDate * updateDate;
@property (nonatomic, retain) PKBrand *brand;
@property (nonatomic, retain) PKSupplementalMedia* supplementalMedia;

@property (nonatomic, retain) NSSet *referencingPackages;
@property (nonatomic, retain) NSOrderedSet *requiredPackages;

@property (nonatomic, retain) NSString* type;
@property (nonatomic, retain) NSString* deploymentStatus;

@property (nonatomic, retain) NSDate* expirationDate;
@property (nonatomic, assign) PackageStatus status;
@property (nonatomic, retain) NSString* latestVersion;
@property (nonatomic, retain) NSString* installedVersion;

@property (nonatomic, assign) double sizeIncludingDependencies;

@property (nonatomic, strong, readonly) PKPresentation* presentation;

@property (nonatomic, strong, readonly) NSString* pathToRoot;

+ (BOOL) loadPackagesAtPath:(NSString*)pathToPackages error:(NSError**)error;

- (BOOL) installUpdate:(NSError**)errorToReturn withPathToRoot:(NSString*)pathToRoot version:(NSString*)version;
- (BOOL) uninstallUpdate:(NSError**)errorToReturn;

+ (NSString*) pathToContentFolder;
- (void) deleteFromDevice;

- (NSArray*) fonts;

@end


@interface PKPackage (CoreDataGeneratedAccessors)

- (void) addRequiredPackagesObject:(PKPackage*)value;
- (void) removeRequiredPackagesObject:(PKPackage*)value;
- (void) addRequiredPackages:(NSOrderedSet*)values;
- (void) removeRequiredPackages:(NSOrderedSet*)values;

- (void) addReferencingPackagesObject:(PKPackage*)value;
- (void) removeReferencingPackagesObject:(PKPackage*)value;
- (void) addReferencingPackages:(NSOrderedSet*)values;
- (void) removeReferencingPackages:(NSOrderedSet*)values;

@end


@interface NSManagedObjectContext (Package)

- (PKPackage*) findPackageWithIdentifier:(NSString*)identifier error:(NSError**)error;
- (PKPackage*) findPackageWithName:(NSString*)name;
- (PKPackage*) findPackageWithIdFromCMS:(NSInteger)idFromCMS;
- (PKPackage*) findPackageWithIdFromCMS:(NSInteger)idFromCMS orInsert:(void(^)(PKPackage* content))didInsert;
- (PKPackage*) findPackageWithName:(NSString*)name orInsert:(void(^)(PKPackage* content))didInsert;

@end
