
@interface PKResourceURLProtocol : NSURLProtocol
@end
