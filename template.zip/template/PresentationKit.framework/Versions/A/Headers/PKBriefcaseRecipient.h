#import <PresentationKit/PKPerson.h>

@class PKBriefcase;

@interface PKBriefcaseRecipient : PKPerson

@property (strong, nonatomic) PKBriefcase* briefcase;

@end
