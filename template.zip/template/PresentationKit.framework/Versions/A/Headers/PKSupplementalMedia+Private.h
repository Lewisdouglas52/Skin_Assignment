#import "PKSupplementalMedia.h"

@interface PKSupplementalMedia (Private)

-(BOOL) _completeInstallation:(NSError**)error;

@end