#import <CoreData/CoreData.h>

@interface PKManagedObject : NSManagedObject
@end
