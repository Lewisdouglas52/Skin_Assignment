
@interface PKPackageURLProtocol : NSURLProtocol
+ (NSString*) pathToResourceForPackageURL:(NSURL*)URL;
@end
