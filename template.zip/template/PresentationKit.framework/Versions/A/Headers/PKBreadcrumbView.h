@class PKBreadcrumbItemView;
@class PKFlow;

@interface PKBreadcrumbView : UIView

@property (nonatomic, strong) PKBreadcrumbItemView* selectedItem;
@property (nonatomic, strong, readonly) NSArray* divergentSection;
@property (nonatomic, strong, readonly) PKBreadcrumbItemView* divergentSectionAnchor;
@property (nonatomic, strong) UIColor* breadcrumbMainColor;
@property (nonatomic, strong) UIColor* breadcrumbSubColor;
@property (nonatomic, strong) UIColor* breadcrumbSelectedColor;
@property (nonatomic, strong) UIColor* breadcrumbLineColor;
@property (nonatomic) BOOL showBreadcrumbLine;

-(void) setBreadcrumbsBySection:(NSArray *)breadcrumbsBySection withSelectedFlow:(PKFlow*)selectedFlow;
-(void) setDivergentSection:(NSArray *)divergentSection relativeToBreadcrumb:(PKBreadcrumbItemView*)breadcrumb;

@end